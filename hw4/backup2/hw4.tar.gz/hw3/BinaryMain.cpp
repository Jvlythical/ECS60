#include "BinaryLLHeap.h"

int main(int argc, char* argv[])
{
  BinaryLLHeap <int> heap;
  heap.insert(5);
  return 0;
}
 
