#include <iostream>
#include <cstdlib>

#include "HashTable.h"

using namespace std;

struct PersonWrapper {
    int id;
};

int main() {
     
   //QuadraticHashTable <int> hashTable(-1, 100);
    //shTable.insert(1, 4371); 
    
   //out << "Found" << hashTable.find(1) << endl;
   
    PersonWrapper p;
    p.id = -1;
    QuadraticHashTable<PersonWrapper> ht(p, 100000);
    
    for(int i = 0; i < 1000; i++) {
        p.id = rand() % 10;
        ht.insert(p.id, p);
    } 
    
    for(int n = 999; n >= 0; n--) {
        cout << "HERE" << ht.find(n).id << endl;
    }
     
    return 0;
} 