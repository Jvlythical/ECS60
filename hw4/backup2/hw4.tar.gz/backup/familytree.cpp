// Author: Sean Davis

#include "familytree.h"

FamilyTree::FamilyTree(Family *families, int familyCount)
{
} // FamilyTree()

void FamilyTree::runQueries(Query *queries, Person *answers, int queryCount)
{
  
}  // runQueries()



