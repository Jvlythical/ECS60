#include "scheduler.h"


Scheduler::Scheduler(int numJobs, int numWorkers, Job *jobs, int numPeople)
{
} // Scheduler()


void Scheduler::run()
{
} // run()


