make clean
make timetest3.out
./timetest3.out < input
